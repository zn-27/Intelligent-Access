/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2015 University of Campinas (Unicamp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Luciano Chaves <luciano@lrc.ic.unicamp.br>
 */

#include <wordexp.h>
#include <ns3/uinteger.h>
#include <ns3/tcp-socket-factory.h>
#include "ofswitch13-controller.h"
#include <iomanip>


namespace ns3
{

  NS_LOG_COMPONENT_DEFINE("OFSwitch13Controller");
  NS_OBJECT_ENSURE_REGISTERED(OFSwitch13Controller);

  /********** Public methods ***********/
  OFSwitch13Controller::OFSwitch13Controller()
      : m_serverSocket(0)
  {
    NS_LOG_FUNCTION(this);

    m_xid = rand() & 0xffffffff;
  }

  OFSwitch13Controller::~OFSwitch13Controller()
  {
    NS_LOG_FUNCTION(this);
  }

  TypeId
  OFSwitch13Controller::GetTypeId(void)
  {
    static TypeId tid = TypeId("ns3::OFSwitch13Controller")
                            .SetParent<Object>()
                            .SetGroupName("OFSwitch13")
                            .AddAttribute("Port",
                                          "Port number to listen for incoming packets.",
                                          UintegerValue(6653),
                                          MakeUintegerAccessor(&OFSwitch13Controller::m_port),
                                          MakeUintegerChecker<uint16_t>());
    return tid;
  }

  void
  OFSwitch13Controller::DoDispose()
  {
    NS_LOG_FUNCTION(this);

    m_serverSocket = 0;
    m_addrSwMap.clear();
    m_barrierMap.clear();
    m_commandsMap.clear();
    m_dpIdSwMap.clear();
    m_echoMap.clear();

    Application::DoDispose();
  }

  int OFSwitch13Controller::DpctlExecute(uint64_t dpId, const std::string textCmd)
  {
    NS_LOG_FUNCTION(this << dpId << textCmd);

    Ptr<const RemoteSwitch> swtch = GetRemoteSwitch(dpId);
    if (!swtch)
    {
      // Save this command for further execution after handshake procedure.
      NS_LOG_DEBUG("Schedulling command for an unregistered switch.");
      auto it = m_commandsMap.find(dpId);
      if (it == m_commandsMap.end())
      {
        // Create a new pending commands object for this datapath id.
        Ptr<PendingCommands> pendCmds = Create<PendingCommands>();
        std::pair<uint64_t, Ptr<PendingCommands>> entry(dpId, pendCmds);
        auto ret = m_commandsMap.insert(entry);
        if (ret.second == false)
        {
          NS_LOG_ERROR("Error when creating pending commands object.");
        }
        it = ret.first;
      }

      // Save the dpctl command in the pending queue and return.
      it->second->m_queue.push(textCmd);
      return 0;
    }

    // Parse the textCmd.
    wordexp_t cmd;
    wordexp(textCmd.c_str(), &cmd, 0);
    char **argv = cmd.we_wordv;
    size_t argc = cmd.we_wordc;

    // Check for unsupported commands.
    if ((strcmp(argv[0], "ping") == 0) || (strcmp(argv[0], "monitor") == 0) || (strcmp(argv[0], "set-desc") == 0) || (strcmp(argv[0], "queue-mod") == 0) || (strcmp(argv[0], "queue-del") == 0))
    {
      NS_LOG_ERROR("Dpctl experimenter command currently not supported.");
      wordfree(&cmd);
      return EXIT_FAILURE;
    }

    // Execute the command.
    int ret = dpctl_exec_ns3_command((void *)PeekPointer(swtch), argc, argv);
    wordfree(&cmd);
    return ret;
  }

  void
  OFSwitch13Controller::DpctlSendAndPrint(struct vconn *vconn,
                                          struct ofl_msg_header *msg)
  {
    NS_LOG_FUNCTION_NOARGS();

    Ptr<const RemoteSwitch> swtch((RemoteSwitch *)vconn, true);
    swtch->m_ctrlApp->SendToSwitch(swtch, msg, 0);
  }

  /********* Protected methods *********/
  void
  OFSwitch13Controller::StartApplication()
  {
    NS_LOG_FUNCTION(this << m_port);

    // Create the server listening socket
    TypeId tcpFactory = TypeId::LookupByName("ns3::TcpSocketFactory");
    m_serverSocket = Socket::CreateSocket(GetNode(), tcpFactory);
    m_serverSocket->SetAttribute("SegmentSize", UintegerValue(8900));
    m_serverSocket->Bind(InetSocketAddress(Ipv4Address::GetAny(), m_port));
    m_serverSocket->Listen();

    // Setting socket callbacks
    m_serverSocket->SetAcceptCallback(
        MakeCallback(&OFSwitch13Controller::SocketRequest, this),
        MakeCallback(&OFSwitch13Controller::SocketAccept, this));
    m_serverSocket->SetCloseCallbacks(
        MakeCallback(&OFSwitch13Controller::SocketPeerClose, this),
        MakeCallback(&OFSwitch13Controller::SocketPeerError, this));
  }

  void
  OFSwitch13Controller::StopApplication()
  {
    NS_LOG_FUNCTION(this << m_port);

    for (auto const &it : m_dpIdSwMap)
    {
      Ptr<RemoteSwitch> swtch = it.second;
      swtch->m_handler = 0;
    }

    if (m_serverSocket)
    {
      m_serverSocket->Close();
      m_serverSocket->SetRecvCallback(
          MakeNullCallback<void, Ptr<Socket>>());
    }

    m_addrSwMap.clear();
    m_barrierMap.clear();
    m_commandsMap.clear();
    m_dpIdSwMap.clear();
    m_echoMap.clear();
  }

  uint32_t
  OFSwitch13Controller::GetNextXid()
  {
    return ++m_xid;
  }

  void
  OFSwitch13Controller::HandshakeSuccessful(Ptr<const RemoteSwitch> swtch)
  {
    NS_LOG_FUNCTION(this << swtch);
  }

  Ptr<const OFSwitch13Controller::RemoteSwitch>
  OFSwitch13Controller::GetRemoteSwitch(uint64_t dpId) const
  {
    NS_LOG_FUNCTION(this << dpId);

    auto it = m_dpIdSwMap.find(dpId);
    if (it != m_dpIdSwMap.end())
    {
      return it->second;
    }
    return 0;
  }

  int OFSwitch13Controller::SendToSwitch(Ptr<const RemoteSwitch> swtch,
                                         struct ofl_msg_header *msg, uint32_t xid)
  {
    NS_LOG_FUNCTION(this << swtch);

    char *msgStr = ofl_msg_to_string(msg, 0);
    NS_LOG_DEBUG("TX to switch " << swtch->GetIpv4() << " [dp " << swtch->GetDpId() << "]: " << msgStr);
    free(msgStr);

    // Set the transaction ID only for unknown values
    if (!xid)
    {
      xid = GetNextXid();
    }

    // Create the packet from the OpenFlow message and send it to the switch.
    return swtch->m_handler->SendMessage(ofs::PacketFromMsg(msg, xid));
  }

  void
  OFSwitch13Controller::SendEchoRequest(Ptr<const RemoteSwitch> swtch,
                                        size_t payloadSize)
  {
    NS_LOG_FUNCTION(this << swtch);

    // Create the echo request message
    struct ofl_msg_echo msg;
    msg.header.type = OFPT_ECHO_REQUEST;
    msg.data_length = payloadSize;
    msg.data = 0;

    // Fill payload with random bytes
    if (payloadSize)
    {
      msg.data = (uint8_t *)xmalloc(payloadSize);
      random_bytes(msg.data, payloadSize);
    }

    // Create and save the echo metadata for this request
    uint32_t xid = GetNextXid();
    std::pair<uint32_t, EchoInfo> entry(xid, EchoInfo(swtch));
    auto ret = m_echoMap.insert(entry);
    if (ret.second == false)
    {
      NS_LOG_ERROR("Error requesting echo to switch " << swtch);
    }

    // Send the message to the switch
    SendToSwitch(swtch, (struct ofl_msg_header *)&msg, xid);

    // Free the payload
    if (payloadSize)
    {
      free(msg.data);
    }
  }
  //-------------------------------zi ding yi ------------------------------------
  void
  OFSwitch13Controller::SetRP()
  {
    std::cout << "设置routinglist优先级中-----------" << std::endl;
    NS_LOG_FUNCTION(this);

    // 遍历控制器当前管理的所有交换机
    for (auto it = m_dpIdSwMap.begin(); it != m_dpIdSwMap.end(); ++it)
    {
      Ptr<const RemoteSwitch> swtch2 = it->second;
      NS_ASSERT(swtch2 != 0);
      std::cout << "Sending message to switch: " << swtch2->GetDpId() << std::endl;
      std::cout << "Sending message to switch22: " << swtch2->m_handler << std::endl;

      // //   创建并清空结构体
      struct adhocl_ext_protocol_config_request msg;
     
      // memset(&msg, 0, sizeof(adhocl_ext_protocol_config_request));
      // ===== 固定字段值 =====
      msg.header.type = ADHOC_EXT_PROTOCOL_CONFIG_REQUEST; // OpenFlow扩展消息
      msg.vendor = 0x12345678;                             // 自定义厂商ID
      msg.subtype = 1001;                                  // 自定义子类型
      // msg.p1 = 100;                                        // 固定参数1
      // msg.p2 = 10;                                         // 固定参数2
      // msg.p3 = 1000;                                       // 固定参数3
      // msg.mac_ad = 0x001122334455ULL;                      // 示例MAC地址
      //=====================

      // struct ofl_msg_header msg2;
      // msg2.type = OFPT_BARRIER_REQUEST;

      uint32_t xid = GetNextXid();
      std::cout << "交换机xxxx:--" << sizeof(adhocp_ext_protocol_config_request) << std::endl;
      // 发送消息到交换机
      int ret = SendToSwitch(swtch2, (struct ofl_msg_header *)&msg, xid);
      std::cout << "交换机llll" << std::endl;
      if (ret != 0)
      {
        NS_LOG_ERROR("Failed to send SetPriority message to switch " << swtch2->GetDpId());
      }
      else
      {
        NS_LOG_INFO("Sent SetPriority message to switch " << swtch2->GetDpId());
      }
    }
  }
  //用于修改无线域的节点优先级
  void
  OFSwitch13Controller::SetRPtoAll()
  { 
    std::cout<<"准备发送 set0 报文到交换机..."<<std::endl;
    NS_LOG_FUNCTION(this);

    // 控制器发送到随机交换机.
    //Ptr<const RemoteSwitch> swtch = GetRandomRemoteSwitch();
    Ptr<const RemoteSwitch> swtch = GetRemoteSwitch(3);
    NS_ASSERT(swtch != 0);
    std::cout << "Sending set0 to switch: " << swtch->GetDpId() << std::endl;

    struct adhocl_ext_test msg;

    //==========固定字段============
     msg.header.type = ADHOC_EXT_TEST;
     msg.vendor      = 0x12345678;
     msg.subtype     = 4001;

    // 设置路由协议优先级
     msg.p1 = 100;   // AODV
     msg.p2 = 50;    // OLSR
     msg.p3 = 10;    // STATIC
     msg.p4 = 0;     //可能的协议拓展
     msg.p5 = 0;     //可能的协议的拓展
    // 获取唯一 XID
     uint32_t xid = GetNextXid();

     // 调用已有的发送接口
     int ret = SendToSwitch(swtch, (struct ofl_msg_header *)&msg, xid);

     if (ret != 0)
     {
        NS_LOG_ERROR("发送 set0 报文失败, switch " << swtch->GetDpId());
     }
     else
      {   
        NS_LOG_INFO("成功发送 set0 报文到 switch " << swtch->GetDpId());
      }

  }
  //用于修改单个节点的优先级
  void
  OFSwitch13Controller::SetRPtoSingle(uint64_t mac_address)
  { 
    std::cout<<"准备发送 set 报文到交换机..."<<std::endl;
    NS_LOG_FUNCTION(this);

    // 控制器发送到随机交换机.
    //Ptr<const RemoteSwitch> swtch = GetRandomRemoteSwitch();
    Ptr<const RemoteSwitch> swtch = GetRemoteSwitch(3);
    NS_ASSERT(swtch != 0);
    std::cout << "Sending set to switch: " << swtch->GetDpId() << std::endl;

    struct adhocl_ext_protocol_set msg;

    //==========固定字段============
     msg.header.type = ADHOC_EXT_PROTOCOL_SET;
     msg.vendor      = 0x12345678;
     msg.subtype     = 8001;

    // 设置路由协议优先级
     msg.p1 = 100;   // AODV
     msg.p2 = 50;    // OLSR
     msg.p3 = 10;    // STATIC
     msg.mac_ad = mac_address;
     memset(msg.pad1, 0x00, 2);
    // 获取唯一 XID
     uint32_t xid = GetNextXid();

     // 调用已有的发送接口
     int ret = SendToSwitch(swtch, (struct ofl_msg_header *)&msg, xid);

     if (ret != 0)
     {
        NS_LOG_ERROR("发送 set 报文失败, switch " << swtch->GetDpId());
     }
     else
      {   
        NS_LOG_INFO("成功发送 set 报文到 switch " << swtch->GetDpId());
      }

  }
  //---------------------修改组网模式----------------------
  void
  OFSwitch13Controller::ChangeDeviceLogical(uint32_t op)
  {
    std::cout<<"准备域内无线节点切换组网模式--------"<<std::endl;
    NS_LOG_FUNCTION(this);
    // 需要决策模块自行选择op=1 or 2 or 3....

    // 测试：直接发给c域的交换机
        Ptr<const RemoteSwitch> swtch = GetRemoteSwitch(3);
        NS_ASSERT(swtch != 0);

        std::cout << "Sending logicalchange msg to switch: " << swtch->GetDpId() << std::endl;

        struct adhocl_ext_changelogical msg;

        //=======固定字段，后期可拓展数据======
        msg.header.type = ADHOC_EXT_CHANGELOGICAL;
        msg.vendor      = 0x12345678;
        msg.subtype     = 7001;

        msg.op          = op; 
        msg.ip_address  = Ipv4Address("10.3.1.3").Get();
      
        // 获取唯一 XID
        uint32_t xid = GetNextXid();

        // 调用已有的发送接口
        int ret = SendToSwitch(swtch, (struct ofl_msg_header *)&msg, xid);

        if (ret != 0)
        {
            NS_LOG_ERROR("发送 changelogical 报文失败, switch " << swtch->GetDpId());
        }
        else
        {   
            NS_LOG_INFO("成功发送 changelogical 报文到 switch " << swtch->GetDpId());
        }

  }

  //-----------------------------------------
  void
  OFSwitch13Controller::SendBarrierRequest(Ptr<const RemoteSwitch> swtch)
  {
    NS_LOG_FUNCTION(this << swtch);

    // Create the barrier request message
    struct ofl_msg_header msg;
    msg.type = OFPT_BARRIER_REQUEST;

    // Create and save the barrier metadata for this request
    uint32_t xid = GetNextXid();
    std::pair<uint32_t, BarrierInfo> entry(xid, BarrierInfo(swtch));
    auto ret = m_barrierMap.insert(entry);
    if (ret.second == false)
    {
      NS_LOG_ERROR("Error requesting barrier to switch " << swtch);
    }

    // Send the message to the switch
    SendToSwitch(swtch, &msg, xid);
  }

  // --- BEGIN: Handlers functions -------
  ofl_err
  OFSwitch13Controller::HandleEchoRequest(
      struct ofl_msg_echo *msg, Ptr<const RemoteSwitch> swtch,
      uint32_t xid)
  {
    NS_LOG_FUNCTION(this << swtch << xid);

    // Create the echo reply message
    struct ofl_msg_echo reply;
    reply.header.type = OFPT_ECHO_REPLY;
    reply.data_length = msg->data_length;
    reply.data = msg->data;
    SendToSwitch(swtch, (struct ofl_msg_header *)&reply, xid);
    ofl_msg_free((struct ofl_msg_header *)msg, 0);
    return 0;
  }

  ofl_err
  OFSwitch13Controller::HandleEchoReply(
      struct ofl_msg_echo *msg, Ptr<const RemoteSwitch> swtch,
      uint32_t xid)
  {
    NS_LOG_FUNCTION(this << swtch << xid);

    auto it = m_echoMap.find(xid);
    if (it == m_echoMap.end())
    {
      NS_LOG_WARN("Echo response for unknonw echo request.");
    }
    else
    {
      it->second.m_waiting = false;
      it->second.m_recv = Simulator::Now();
      NS_LOG_INFO("Echo reply from " << it->second.m_swtch->GetIpv4() << " with RTT " << it->second.GetRtt().As(Time::MS));
      m_echoMap.erase(it);
    }

    ofl_msg_free((struct ofl_msg_header *)msg, 0);
    return 0;
  }

  ofl_err
  OFSwitch13Controller::HandleBarrierReply(
      struct ofl_msg_header *msg, Ptr<const RemoteSwitch> swtch,
      uint32_t xid)
  {
    NS_LOG_FUNCTION(this << swtch << xid);

    auto it = m_barrierMap.find(xid);
    if (it == m_barrierMap.end())
    {
      NS_LOG_WARN("Barrier response for unknonw barrier request.");
    }
    else
    {
      NS_LOG_INFO("Barrier reply from " << it->second.m_swtch->GetIpv4());
      m_barrierMap.erase(it);
    }

    ofl_msg_free(msg, 0);
    return 0;
  }

  ofl_err
  OFSwitch13Controller::HandleHello(
      struct ofl_msg_header *msg, Ptr<const RemoteSwitch> swtch,
      uint32_t xid)
  {
    NS_LOG_FUNCTION(this << swtch << xid);

    // We got the hello message from the switch. Let's proceed with the handshake
    // and request the switch features.
    ofl_msg_free(msg, 0);

    struct ofl_msg_header features;
    features.type = OFPT_FEATURES_REQUEST;
    SendToSwitch(swtch, &features);
    SendBarrierRequest(swtch);

    return 0;
  }

  ofl_err
  OFSwitch13Controller::HandleFeaturesReply(
      struct ofl_msg_features_reply *msg, Ptr<RemoteSwitch> swtch,
      uint32_t xid)
  {
    NS_LOG_FUNCTION(this << swtch << xid);

    // We got the features reply message from the switch. Let's save switch
    // features into metadata structure.
    swtch->m_dpId = msg->datapath_id;
    swtch->m_nBuffers = msg->n_buffers;
    swtch->m_nTables = msg->n_tables;
    swtch->m_auxiliaryId = msg->auxiliary_id;
    swtch->m_capabilities = msg->capabilities;
    ofl_msg_free((struct ofl_msg_header *)msg, 0);

    std::pair<uint64_t, Ptr<RemoteSwitch>> entry(swtch->m_dpId, swtch);
    auto ret = m_dpIdSwMap.insert(entry);
    if (ret.second == false)
    {
      NS_LOG_ERROR("This switch is already registered with this controller.");
    }

    // Execute any pending command for this OpenFlow datapath ID.
    auto it = m_commandsMap.find(swtch->m_dpId);
    if (it != m_commandsMap.end())
    {
      Ptr<PendingCommands> pendCommands = it->second;
      while (!pendCommands->m_queue.empty())
      {
        DpctlExecute(swtch->m_dpId, pendCommands->m_queue.front());
        pendCommands->m_queue.pop();
      }
      m_commandsMap.erase(swtch->m_dpId);
    }

    // Notify listeners that the handshake procedure is concluded.
    HandshakeSuccessful(swtch);
    return 0;
  }

  ofl_err
  OFSwitch13Controller::HandlePacketIn(
      struct ofl_msg_packet_in *msg, Ptr<const RemoteSwitch> swtch,
      uint32_t xid)
  {
    NS_LOG_FUNCTION(this << swtch << xid);

    ofl_msg_free((struct ofl_msg_header *)msg, 0);
    return 0;
  }

  ofl_err
  OFSwitch13Controller::HandleError(
      struct ofl_msg_error *msg, Ptr<const RemoteSwitch> swtch,
      uint32_t xid)
  {
    NS_LOG_FUNCTION(this << swtch << xid);

    char *msgStr = ofl_msg_to_string((struct ofl_msg_header *)msg, 0);
    NS_LOG_ERROR("OpenFlow error: " << msgStr);
    free(msgStr);

    ofl_msg_free((struct ofl_msg_header *)msg, 0);
    return 0;
  }

  ofl_err
  OFSwitch13Controller::HandleGetConfigReply(
      struct ofl_msg_get_config_reply *msg, Ptr<const RemoteSwitch> swtch,
      uint32_t xid)
  {
    NS_LOG_FUNCTION(this << swtch << xid);

    ofl_msg_free((struct ofl_msg_header *)msg, 0);
    return 0;
  }

  ofl_err
  OFSwitch13Controller::HandleFlowRemoved(
      struct ofl_msg_flow_removed *msg, Ptr<const RemoteSwitch> swtch,
      uint32_t xid)
  {
    NS_LOG_FUNCTION(this << swtch << xid);

    ofl_msg_free_flow_removed(msg, true, 0);
    return 0;
  }

  ofl_err
  OFSwitch13Controller::HandlePortStatus(
      struct ofl_msg_port_status *msg, Ptr<const RemoteSwitch> swtch,
      uint32_t xid)
  {
    NS_LOG_FUNCTION(this << swtch << xid);

    ofl_msg_free((struct ofl_msg_header *)msg, 0);
    return 0;
  }

  ofl_err
  OFSwitch13Controller::HandleAsyncReply(
      struct ofl_msg_async_config *msg, Ptr<const RemoteSwitch> swtch,
      uint32_t xid)
  {
    NS_LOG_FUNCTION(this << swtch << xid);

    ofl_msg_free((struct ofl_msg_header *)msg, 0);
    return 0;
  }

  ofl_err
  OFSwitch13Controller::HandleMultipartReply(
      struct ofl_msg_multipart_reply_header *msg, Ptr<const RemoteSwitch> swtch,
      uint32_t xid)
  {
    NS_LOG_FUNCTION(this << swtch << xid);

    ofl_msg_free((struct ofl_msg_header *)msg, 0);
    return 0;
  }

  ofl_err
  OFSwitch13Controller::HandleRoleReply(
      struct ofl_msg_role_request *msg, Ptr<const RemoteSwitch> swtch,
      uint32_t xid)
  {
    NS_LOG_FUNCTION(this << swtch << xid);

    ofl_msg_free((struct ofl_msg_header *)msg, 0);
    return 0;
  }

  ofl_err
  OFSwitch13Controller::HandleQueueGetConfigReply(
      struct ofl_msg_queue_get_config_reply *msg, Ptr<const RemoteSwitch> swtch,
      uint32_t xid)
  {
    NS_LOG_FUNCTION(this << swtch << xid);

    ofl_msg_free((struct ofl_msg_header *)msg, 0);
    return 0;
  }
  //新增handlers function-------------------
  ofl_err
  OFSwitch13Controller::HandleAdhocReply(struct adhocl_ext_protocol_config_reply *msg,
                                        Ptr<const RemoteSwitch> swtch,uint32_t xid)                          
  {
    NS_LOG_FUNCTION(this << swtch << xid);
    NS_LOG_INFO("Received ADHOC_EXT_PROTOCOL_CONFIG_REPLY from switch " << swtch->GetDpId());

    std::cout << "\n[Controller] Received ADHOC_EXT_PROTOCOL_CONFIG_REPLY" <<
                 " from switch"<<swtch->GetDpId()<< std::endl;

    // 如果需要，可保存或触发其他逻辑
    uint64_t dpId = swtch->GetDpId();
    // 创建一个 StaInfo
    StaInfo sta;
    sta.mac = msg->mac_ad;
    sta.p1 = msg->p1;
    sta.p2 = msg->p2;
    sta.p3 = msg->p3;
    sta.vendor = msg->vendor;
    sta.subtype = msg->subtype;
    sta.lastUpdate = Simulator::Now();
    // 插入或更新该 STA
    bool found = false;
    for (auto &existingSta : m_switchStaTable[dpId])
    {
      if (existingSta.mac == sta.mac)
      {
        existingSta = sta; // 更新
        found = true;
        break;
      }
    }

    if (!found)
    {
      m_switchStaTable[dpId].push_back(sta); // 新增
    }
    std::cout << "[Controller] STA reply stored under switch " << dpId
              << " (Total STA count = " << m_switchStaTable[dpId].size() << ")" << std::endl;

    //经过策略决策后调用set/test报文
    if(m_switchStaTable[dpId].size()==3)
    {
      SetRPtoAll();
      //SetRPtoSingle(sta.mac);
    }
    // 释放消息资源
    ofl_msg_free((struct ofl_msg_header *)msg, 0);
    return 0;
  }
    // //------------------zi ding yi ---------------------------
    // //自定义的交换机发给控制器的主机信息消息
    ofl_err
    OFSwitch13Controller::HandleAdhocExtStaInfo(
          struct adhocl_ext_stainfo *msg, Ptr<const RemoteSwitch> swtch,uint32_t xid)
    {
        NS_LOG_FUNCTION(this << swtch << xid);

        // 基础实现，派生类可以覆盖此实现
        ofl_msg_free((struct ofl_msg_header *)msg, 0);
        return 0;
    }
    ofl_err
    OFSwitch13Controller::HandleAdhocExtNodeStatusReport(
          struct adhocl_ext_node_status_report *msg, Ptr<const RemoteSwitch> swtch,uint32_t xid)
    {
        NS_LOG_FUNCTION(this << swtch << xid);

         // 基础实现，派生类可以覆盖此实现
        ofl_msg_free((struct ofl_msg_header *)msg, 0);
        return 0;
    }
  // --- END: Handlers functions -------

  /********** Private methods **********/
  ofl_err
  OFSwitch13Controller::HandleSwitchMsg(
      struct ofl_msg_header *msg, Ptr<RemoteSwitch> swtch, uint32_t xid)
  {
    NS_LOG_FUNCTION(this << swtch << xid);

    // Dispatches control messages to appropriate handler functions.
    switch (msg->type)
    {
    case OFPT_HELLO:
      return HandleHello(msg, swtch, xid);

    case OFPT_BARRIER_REPLY:
      return HandleBarrierReply(msg, swtch, xid);

    case OFPT_PACKET_IN:
      return HandlePacketIn(
          (struct ofl_msg_packet_in *)msg, swtch, xid);

    case OFPT_ECHO_REQUEST:
      return HandleEchoRequest(
          (struct ofl_msg_echo *)msg, swtch, xid);

    case OFPT_ECHO_REPLY:
      return HandleEchoReply(
          (struct ofl_msg_echo *)msg, swtch, xid);

    case OFPT_ERROR:
      return HandleError(
          (struct ofl_msg_error *)msg, swtch, xid);

    case OFPT_FEATURES_REPLY:
      return HandleFeaturesReply(
          (struct ofl_msg_features_reply *)msg, swtch, xid);

    case OFPT_GET_CONFIG_REPLY:
      return HandleGetConfigReply(
          (struct ofl_msg_get_config_reply *)msg, swtch, xid);

    case OFPT_FLOW_REMOVED:
      return HandleFlowRemoved(
          (struct ofl_msg_flow_removed *)msg, swtch, xid);

    case OFPT_PORT_STATUS:
      return HandlePortStatus(
          (struct ofl_msg_port_status *)msg, swtch, xid);

    case OFPT_GET_ASYNC_REPLY:
      return HandleAsyncReply(
          (struct ofl_msg_async_config *)msg, swtch, xid);

    case OFPT_MULTIPART_REPLY:
      return HandleMultipartReply(
          (struct ofl_msg_multipart_reply_header *)msg, swtch, xid);

    case OFPT_ROLE_REPLY:
      return HandleRoleReply(
          (struct ofl_msg_role_request *)msg, swtch, xid);

    case OFPT_QUEUE_GET_CONFIG_REPLY:
      return HandleQueueGetConfigReply(
          (struct ofl_msg_queue_get_config_reply *)msg, swtch, xid);

    //自定义分支case ADHOC_EXT_PROTOCOL_CONFIG_REPLY:
    case ADHOC_EXT_PROTOCOL_CONFIG_REPLY:
        return HandleAdhocReply(
          (struct adhocl_ext_protocol_config_reply*)msg,swtch,xid);
    //自定义分支2case ADHOC_EXT_STAINFO:
    case ADHOC_EXT_STAINFO:
     {
      NS_LOG_INFO("Received STA message: ADHOC_EXT_STAINFO from switch");
      std::cout<<"STA message lai le -------------------"<<std::endl;
      return HandleAdhocExtStaInfo(
        (struct adhocl_ext_stainfo*) msg, swtch,xid);
     } 
     //自定义分支3case adhocl_ext_node_status_report
     case ADHOC_EXT_NODE_STATUS_REPORT:
     {
      std::cout<<"位置信息来了"<<std::endl;
      struct adhocl_ext_node_status_report *rep = (adhocl_ext_node_status_report *)msg;
      std::cout<<"ip: "<<rep->ip_address<<"空间坐标：x= "<<rep->x<<" y= "
               <<rep->y<<" z= "<<rep->z<<std::endl;

    // // ========== 关键修复1：强转为自定义结构体类型 ==========
    // struct adhocl_ext_node_status_report *statusMsg = 
    //     (struct adhocl_ext_node_status_report *)msg;

    // // ========== 关键修复2：正确的IP地址转换（NS3 标准API） ==========
    // Ipv4Address ip(statusMsg->ip_address);
    // std::ostringstream ipStream;
    // ipStream << ip;  // NS3 Ipv4Address 支持流输出，替代错误的 ToString()
    // std::string ipStr = ipStream.str();

    // // ========== 格式化输出（使用强转后的结构体） ==========

    // std::cout << "节点IP:     " << ipStr << "空间坐标:   X=" << std::setw(4) << statusMsg->x << " m, "
    //           << "Y=" << std::setw(4) << statusMsg->y << " m, "
    //           << "Z=" << std::setw(4) << statusMsg->z << " m" << std::endl;
      return HandleAdhocExtNodeStatusReport(
        (struct adhocl_ext_node_status_report*) msg, swtch,xid);
     }
    case OFPT_EXPERIMENTER:
    default:
      return ofl_error(OFPET_BAD_REQUEST, OFPGMFC_BAD_TYPE);
    }
  }

  void
  OFSwitch13Controller::ReceiveFromSwitch(Ptr<Packet> packet, Address from)
  {
    NS_LOG_FUNCTION(this << packet);

    uint32_t xid;
    struct ofl_msg_header *msg;
    ofl_err error;

    // Get the openflow buffer, unpack the message and send to message handler
    struct ofpbuf *buffer = ofs::BufferFromPacket(packet, packet->GetSize());
    error = ofl_msg_unpack((uint8_t *)buffer->data, buffer->size, &msg, &xid, 0);

    if (!error)
    {
      Ptr<RemoteSwitch> swtch = GetRemoteSwitch(from);
      char *msgStr = ofl_msg_to_string(msg, 0);
      NS_LOG_DEBUG("RX from switch " << swtch->GetIpv4() << " [dp " << swtch->GetDpId() << "]: " << msgStr);
      free(msgStr);

      error = HandleSwitchMsg(msg, swtch, xid);
      if (error)
      {
        // NOTE: It is assumed that if a handler returns with error, it did
        // not use any part of the control message, thus it can be freed up.
        // If no error is returned however, the message must be freed inside
        // the handler (because the handler might keep parts of the message)
        ofl_msg_free(msg, 0);
      }
    }
    if (error)
    {
      NS_LOG_ERROR("Error processing OpenFlow message from switch.");
    }
    ofpbuf_delete(buffer);
  }

  Ptr<OFSwitch13Controller::RemoteSwitch>
  OFSwitch13Controller::GetRemoteSwitch(Address address)
  {
    NS_LOG_FUNCTION(this << address);

    auto it = m_addrSwMap.find(address);
    if (it != m_addrSwMap.end())
    {
      return it->second;
    }
    NS_ABORT_MSG("Couldn't find the remote switch for this address.");
  }

  //----------------test：随机获取一个交换机实例---------------
  Ptr<const OFSwitch13Controller::RemoteSwitch>
  OFSwitch13Controller::GetRandomRemoteSwitch()
  { 
      NS_LOG_FUNCTION(this);

      // 1. 判空
      if (m_dpIdSwMap.empty())
      { 
          std::cout<<"没有交换机与之相连"<<std::endl;
          NS_LOG_WARN("GetRandomRemoteSwitch: no switches available.");
          return nullptr;
      }

     // 2. 创建 ns-3 随机变量
      Ptr<UniformRandomVariable> uv = CreateObject<UniformRandomVariable>();
      uint32_t index = uv->GetInteger(0, m_dpIdSwMap.size()-1);

      // 3. 定位到随机位置
      auto it = m_dpIdSwMap.begin();
      std::advance(it, index);

      NS_LOG_INFO("Randomly selected switch dpid=" << it->first);

      // 返回 RemoteSwitch
      return it->second;
  }


  bool
  OFSwitch13Controller::SocketRequest(Ptr<Socket> socket, const Address &from)
  {
    NS_LOG_FUNCTION(this << socket << from);

    NS_ASSERT_MSG(InetSocketAddress::IsMatchingType(from),
                  "Invalid address type (only IPv4 supported by now).");
    Ipv4Address ipAddr = InetSocketAddress::ConvertFrom(from).GetIpv4();
    uint16_t port = InetSocketAddress::ConvertFrom(from).GetPort();
    NS_LOG_INFO("Switch request connection from " << ipAddr << ":" << port);

    return true;
  }

  void
  OFSwitch13Controller::SocketAccept(Ptr<Socket> socket, const Address &from)
  {
    NS_LOG_FUNCTION(this << socket << from);

    Ipv4Address ipAddr = InetSocketAddress::ConvertFrom(from).GetIpv4();
    uint16_t port = InetSocketAddress::ConvertFrom(from).GetPort();
    NS_LOG_INFO("Switch connection accepted from " << ipAddr << ":" << port);

    // This is a new switch connection to this controller.
    // Let's create the remote switch metadata and save it.
    Ptr<RemoteSwitch> swtch = Create<RemoteSwitch>();
    swtch->m_address = from;
    swtch->m_ctrlApp = Ptr<OFSwitch13Controller>(this);

    // As we have more than one socket that is used for communication between
    // this OpenFlow controller and switches, we need to handle the process of
    // sending/receiving OpenFlow messages to/from sockets in an independent way.
    // So, each socket has its own socket handler to this end.
    swtch->m_handler = CreateObject<OFSwitch13SocketHandler>(socket);
    swtch->m_handler->SetReceiveCallback(
        MakeCallback(&OFSwitch13Controller::ReceiveFromSwitch, this));

    std::pair<Address, Ptr<RemoteSwitch>> entry(swtch->m_address, swtch);
    auto ret = m_addrSwMap.insert(entry);
    if (ret.second == false)
    {
      NS_LOG_ERROR("This switch is already registered with this controller.");
    }

    // Let's send the hello message to the switch and wait for the hello message
    // from the switch to proceed with the handshake procedure.
    struct ofl_msg_header hello;
    hello.type = OFPT_HELLO;
    SendToSwitch(swtch, &hello);
  }

  void
  OFSwitch13Controller::SocketPeerClose(Ptr<Socket> socket)
  {
    NS_LOG_FUNCTION(this << socket);

    NS_LOG_DEBUG("Connection successfully closed.");
    socket->ShutdownSend();
    socket->ShutdownRecv();
  }

  void
  OFSwitch13Controller::SocketPeerError(Ptr<Socket> socket)
  {
    NS_LOG_FUNCTION(this << socket);

    NS_LOG_ERROR("Socket peer error " << socket);
    socket->ShutdownSend();
    socket->ShutdownRecv();
  }

  OFSwitch13Controller::RemoteSwitch::RemoteSwitch()
      : m_handler(0),
        m_ctrlApp(0),
        m_dpId(0),
        m_role(OFPCR_ROLE_EQUAL)
  {
    m_address = Address();
  }

  Ipv4Address
  OFSwitch13Controller::RemoteSwitch::GetIpv4(void) const
  {
    return InetSocketAddress::ConvertFrom(m_address).GetIpv4();
  }

  uint16_t
  OFSwitch13Controller::RemoteSwitch::GetPort(void) const
  {
    return InetSocketAddress::ConvertFrom(m_address).GetPort();
  }

  uint64_t
  OFSwitch13Controller::RemoteSwitch::GetDpId(void) const
  {
    return m_dpId;
  }

  OFSwitch13Controller::EchoInfo::EchoInfo(Ptr<const RemoteSwitch> swtch)
      : m_waiting(true),
        m_send(Simulator::Now()),
        m_swtch(swtch)
  {
  }

  Time
  OFSwitch13Controller::EchoInfo::GetRtt(void) const
  {
    if (m_waiting)
    {
      return Time(-1);
    }
    else
    {
      return m_recv - m_send;
    }
  }

  OFSwitch13Controller::BarrierInfo::BarrierInfo(Ptr<const RemoteSwitch> swtch)
      : m_waiting(true),
        m_swtch(swtch)
  {
  }

  OFSwitch13Controller::PendingCommands::PendingCommands()
  {
  }

} // namespace ns3
